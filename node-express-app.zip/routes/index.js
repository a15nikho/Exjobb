var express = require('express');
var router = express.Router();
//var MongoClient = require('mongodb').MongoClient;
var nano = require('nano')('http://localhost:5984');
nano.db.create('couchtest');
var couchtest = nano.db.use('couchtest');
var objectId = require('mongodb').ObjectID;
var assert = require('assert');

var url = 'mongodb://localhost:27017/test'; //url till databas och sedan definieras vilken databas
var dbName = 'test';
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Home', condition: true, anyArray: [1,2,3] }); //change title on index.html
});


router.get('/insert', function(req, res, next) {
  res.render('insert', { title: 'Insert ', condition: true, anyArray: [1,2,3] }); //change title on index.html
});

router.get('/update', function(req, res, next) {
  res.render('update', { title: 'Update ', condition: true, anyArray: [1,2,3] }); //change title on index.html
});

router.get('/delete', function(req, res, next) {
  res.render('delete', { title: 'Delete ', condition: true, anyArray: [1,2,3] }); //change title on index.html
});

router.get('/get', function(req, res, next) {
  res.render('get', { title: 'Get ', condition: true, anyArray: [1,2,3] }); //change title on index.html
});


router.get('/get-data', function(req, res, next){
	var resultArray = [];
	MongoClient.connect(url, function(err, client){
		var db = client.db(dbName);
		assert.equal(null, err);
		var cursor = db.collection('user').find();
		cursor.forEach(function(doc, err){
			assert.equal(null, err);
			resultArray.push(doc);
		}, function(){
			client.close();
			res.render('get', {title: "get site", items: resultArray});
		});
	});
});

router.post('/insert', function(req, res, next){
	var item = {
		name: req.body.name,
		year: req.body.year,
		comment: req.body.comment
	};

	MongoClient.connect(url, function(err, client){
		var db = client.db(dbName);
		
		assert.equal(null, err);
		db.collection('user').insertOne(item, function(error, result){
			assert.equal(null, err);
			console.log('Item inserted');
			client.close();
		});
		res.redirect('/');
	});
});

router.post('/update', function(req, res, next){
	var item = {
		name: req.body.name,
		year: req.body.year,
		comment: req.body.comment
	};
	var id = req.body.id;

	MongoClient.connect(url, function(err, client){
		var db = client.db(dbName);
		
		assert.equal(null, err);
		db.collection('user').updateOne({"_id": objectId(id)}, {$set: item}, function(error, result){
			assert.equal(null, err);
			console.log('Item updated');
			client.close();
		});
		res.redirect('/');
	});
});

router.post('/delete', function(req, res, next){
	var id = req.body.id;
	MongoClient.connect(url, function(err, client){
		var db = client.db(dbName);
		
		assert.equal(null, err);
		db.collection('user').deleteOne({"_id": objectId(id)}, function(error, result){
			assert.equal(null, err);
			console.log('Item deleted');
			client.close();
			});
		res.redirect('/');
	});
});


module.exports = router;
